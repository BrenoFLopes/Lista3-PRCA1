﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex03
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string v1;

            Console.Write("Insira o sexo do usuário [F] Feminino // [M] Masculino: ");
            v1 = Console.ReadLine();

            while ((v1 != "M") && (v1 != "F"))
            {
                Console.WriteLine("Valor não reconhecido!");
                Console.Write("Insira o sexo do usuário [F] Feminino // [M] Masculino: ");
                v1 = Console.ReadLine();
            }

            while (v1 == "F")
            {
                Console.WriteLine("Sexo Feminino reconhecido!");
                break;
            }            

            while (v1 == "M")
            {
                Console.WriteLine("Sexo Masculino reconhecido!");
                break;
            }




        }
    }
}
