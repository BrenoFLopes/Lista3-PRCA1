﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex13
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string R;
            Console.WriteLine("Insira um valor POSITIVO para fatorar!");
            do
            {
                double k = 1;
                double valor = 0;                
                double fat = 1;

                Console.WriteLine("Digite um Valor: ");
                valor = double.Parse(Console.ReadLine());

                while (valor < 0)
                {
                    Console.WriteLine("***ERRO!*** Insira um valor POSITIVO para fatorar: ");
                    valor = double.Parse(Console.ReadLine());
                }

                do
                {
                    fat = fat * k;
                    k = k +1;
                }while (k <= valor);

                Console.WriteLine("{0}! = {1}", valor, fat);

                do
                {
                    Console.WriteLine("Deseja executar código novamente?");
                    Console.WriteLine("Insira (S) para Sim ou (N) para Não: ");
                    
                    R = Console.ReadLine();
                } while ((R != "S") && (R != "N"));

            } while (R != "N");
        }
    }
}
