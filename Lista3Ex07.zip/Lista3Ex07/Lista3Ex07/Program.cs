﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;
            double v3;
            string v4;

            v1 = 1;
            v2 = 0;
            v3 = 1;

            while (v3 <= 20)
            {

                while ((v1 >= 1) && (v1 <= 10))
                {
                    v2 = v3 * v1;
                    Console.WriteLine("{0} * {1} = {2}", v3, v1, v2);
                    v1 = v1 + 1;
                }
                Console.Write("Pressione 'ENTER' para continuar.");
                v4 = Console.ReadLine();
                v3 = v3 + 1;
                v1 = 1;
                v2 = 0;
            }
        }
    }
}
