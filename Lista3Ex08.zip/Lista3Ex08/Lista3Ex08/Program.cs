﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double k;
            double soma;
            v1 = 0; // multiplicador
            k = 1; // contador
            soma = 0; // soma


            Console.WriteLine("Soma dos números inteiros de 1 a 100!");
            while ((k >= 1) && (k <= 100))
            {
                soma = k + v1;// PROVA REAL: 1 = 1 + 0 // 3 = 1 + 2 // 6 = 3 + 3 // 10 = 6 + 4 // 15 = 10 + 5 // 21 = 15 + 6 // 28 = 21 + 7 // OK!!
                Console.WriteLine("Soma {0}: {1}", k, soma);
                v1 = soma;    // PROVA REAL: 1 = 1     // 3 = 3     // 6 = 6     // 10 = 10    // 15 = 15     // 21 = 21 
                k = k + 1;    // PROVA REAL: 2 = 1 + 1 // 3 = 2 + 1 // 4 + 3 + 1 // 5  = 4 + 1 // 6 = 5 + 1   // 7 = 8 + 1 
            }
            Console.WriteLine("Fim de soma!");
        }
    }
}
