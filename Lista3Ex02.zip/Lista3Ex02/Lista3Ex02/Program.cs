﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex02
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double v1;
            double v2;

            Console.Write("Insira o 1º número a ser verificado: ");
            v1 = double.Parse(Console.ReadLine());
            Console.Write("Insira o 2º número a ser verificado: ");
            v2 = double.Parse(Console.ReadLine());

            while (v1 >= v2)
            {
                Console.WriteLine("Valor inválido, insira novamente APENAS o segundo valor!");
                Console.Write("Insira o 2º número a ser verificado: ");
                v2 = double.Parse(Console.ReadLine());
            }

            Console.WriteLine("Valores aceitos! --> Nr1: {0} // Nr2: {1}", v1, v2);
        }
    }
}
