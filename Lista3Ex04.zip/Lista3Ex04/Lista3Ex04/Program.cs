﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;
            v1 = 1;
            v2 = 0;

            Console.WriteLine("Tabuada do Número 5!");
            while ((v1 >= 1) && (v1 <= 10))
            {
                 v2 = 5 * v1;
                Console.WriteLine("5 * {0} = {1}", v1, v2);
                v1 = v1 + 1;
            }
            Console.WriteLine("Fim de Tabuada!");

        }
    }
}
