﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex01
{
    internal class Program
    {
        static void Main(string[] args)
        {

            double valor;

            Console.Write("Insira aqui o número a ser verificado: ");
            valor = double.Parse(Console.ReadLine());

            while(valor <= 0)
            {
                Console.WriteLine("Valor inválido, insira novo valor!");
                Console.Write("Insira aqui o número a ser verificado: ");
                valor = double.Parse(Console.ReadLine());
            }

            Console.WriteLine("Valor positivo! Ok!");

        }
    }
}
