﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string resp;
            do
            {
            double n = 0;
            double k = 0;
            double pos = 0;
            double neg = 0;
            double valor = 0;
            

            double maior = 0; //A
            double menor = 0; //B
            double soma = 0;  //C
            double MA = 0;    //D
            double pp = 0;    //E
            double pn = 0;    //F

            
                Console.Write("Insira a seguir quantidade de números desejados (Máx:19): ");
            n = double.Parse(Console.ReadLine());

            while ((n < 0) || (n >= 20))
            {
                Console.WriteLine("Valor não suportado! Insira a quantidade de valores novamente (Máx:19): ");
                n = double.Parse(Console.ReadLine());
            }

            while (k < n)
            {
                k = k + 1;
                Console.Write("Insira o {0}º Valor: ", k);
                valor = double.Parse(Console.ReadLine());


                if (k == 1)
                {
                    maior = menor = valor;
                }
                else
                {
                    if (valor > maior)
                    {
                        maior = valor;
                    }
                    else
                    {
                        menor = valor;
                    }
                }
                soma = soma + valor;
                if (valor >= 0)
                {
                    pos = pos + 1;
                }
                else
                {
                    neg = neg + 1;
                }
            }

            MA = (soma / n);
            pp = pos * 100 / n;
            pn = neg * 100 / n;


            Console.WriteLine("A. Maior Valor: {0}", maior);                //A
            Console.WriteLine("B. Menor Valor: {0}", menor);                //B
            Console.WriteLine("C. Soma dos Valores: {0}", soma);            //C
            Console.WriteLine("D. Média Aritmética: {0}", MA);              //D
            Console.WriteLine("E. Porcentagem dos Positivos: {0}%", pp);    //E
            Console.WriteLine("F. Porcentagem dos Negativos: {0}%", pn);    //F

                do
                {
                    Console.WriteLine("Deseja Executar Novamente?");
                    Console.WriteLine("(S) para Sim // (N) para Não: ");
                    resp = Console.ReadLine();
                }   while ((resp != "S") && (resp != "N"));
                n = 0;
            } while (resp == "S");

            Console.WriteLine("Obrigado!");

        }
    }
}
