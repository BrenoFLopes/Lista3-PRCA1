﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;
            double X;
            double v3;

            v3 = 0;

            Console.Write("Insira um número POSITIVO para tabuada: ");
            X = Double.Parse(Console.ReadLine());
            while (X <= 0)
            {
                Console.WriteLine("Número não aceito! Utilizar apenas números POSITIVOS!");
                Console.Write("Insira um número POSITIVO para tabuada: ");
                X = Double.Parse(Console.ReadLine());
            }

            Console.WriteLine("Defina o intervalo para tabuada!");
            Console.Write("Insira o MENOR valor do intervalo: ");
            v1 = Double.Parse(Console.ReadLine());
            Console.Write("Insira o MAIOR valor do intervalo: ");
            v2 = Double.Parse(Console.ReadLine());

            while (v1 > v2)
            {
                Console.Write("Intervalo 'MÁXIMO' inferior ao 'MÍNIMO', insira novamente o valor MÁXIMO: ");
                v2 = Double.Parse(Console.ReadLine());
            }

            Console.WriteLine("Tabuada do Número {0} no intervalo de {1} a {2}!", X, v2, v1);
            while (v2 >= v1)
            {
                v3 = X * v2;
                Console.WriteLine("{0} * {1} = {2}", X, v2, v3);
                v2 = v2 - 1;
            }
            Console.WriteLine("Fim de Tabuada!");
        }
    }
}
