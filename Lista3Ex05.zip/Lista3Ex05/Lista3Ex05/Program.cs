﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;
            double v3;
            v1 = 1;
            v2 = 0;

            Console.Write("Insira o número POSITIVO para tabuada: ");
            v3 = double.Parse(Console.ReadLine());

            while (v3 < 1)
            {
                Console.Write("Insira o número POSITIVO para tabuada:");
                v3 = double.Parse(Console.ReadLine());
            }

            Console.WriteLine("Tabuada do Número {0}!",v3);
            while ((v1 >= 1) && (v1 <= 10))
            {
                v2 = v3 * v1;
                Console.WriteLine("{2} * {0} = {1}", v1, v2, v3);
                v1 = v1 + 1;
            }
            Console.WriteLine("Fim de Tabuada!");
        }
    }
}
