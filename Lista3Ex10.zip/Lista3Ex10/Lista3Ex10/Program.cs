﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;      
            double maior;
            double k;
            double soma;
            double media;

            maior = 0;
            k = 0;
            soma = 0;

            Console.WriteLine("Insira abaixo os 10 valores POSITIVOS a serem verificados!");

            do
            {
                k = k +1;
                Console.Write("Insira o {0}º Valor POSITIVO a ser verificado: ", k);
                valor = double.Parse(Console.ReadLine());
                while (valor < 0)
                {
                    Console.Write("Insira novamente o {0}º Valor POSITIVO: ", k);
                    valor = double.Parse(Console.ReadLine());
                }

                while (valor > maior)
                {
                    maior = valor;
                }
                soma = soma + valor;
            } while (k < 10);
            media = soma / 10;
            Console.WriteLine("Valores obtidos conforme solicitado: ");
            Console.WriteLine("A. Maior Valor: {0}", maior);
            Console.WriteLine("B. Soma dos Valores: {0}", soma);
            Console.WriteLine("C. Média dos Valores: {0}", media);

        }
    }
}
