﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;
            double k;
           
            v1 = 0; // 
            v2 = 1; //
            k = 0; // contador

            // PROVA REAL: 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181

            Console.WriteLine("Os 30 primeiros números da sequência de Fibonacci: A Razão Áurea!");
            while ((k >= 0) && (k < 30))
            {
                k = k + 1;    // Contador!
                v2 = v1 + v2;
                Console.WriteLine("Razão {0}: {1}", k, v2);

                k = k + 1;    // Contador!
                v1 = v1 + v2;
                Console.WriteLine("Razão {0}: {1}", k, v1);               
            }
            Console.WriteLine("Fim da sequência de Fibonacci !");
        }
    }
}
